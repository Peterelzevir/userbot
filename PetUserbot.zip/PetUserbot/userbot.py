# coding @hiyaok on telegram.

from telethon import TelegramClient, events
from config import *
import asyncio

class Userbot:
    def __init__(self, session_string, api_id, api_hash):
        self.client = TelegramClient(StringSession(session_string), api_id, api_hash, 
                                   device_model=APP_VERSION)
        self.delay = 0
        self.forwarding = False
        self.banned_groups = set()

    async def start(self):
        await self.client.start()
        
        # Check expiry every hour
        asyncio.create_task(self._check_expiry())
        
        @self.client.on(events.NewMessage(pattern=r'[!/\.]send'))
        async def send_handler(event):
            if not event.is_reply:
                return
            
            if self.delay == 0:
                await event.respond("⚠️ Please set delay first using .setdelay command")
                return
                
            self.forwarding = True
            replied_msg = await event.get_reply_message()
            
            success = 0
            failed = 0
            failed_groups = []
            
            async for dialog in self.client.iter_dialogs():
                if not self.forwarding:
                    break
                    
                if dialog.is_group and dialog.id not in self.banned_groups:
                    try:
                        await self.client.forward_messages(dialog.id, replied_msg)
                        success += 1
                        await asyncio.sleep(self.delay * 60)
                    except Exception as e:
                        failed += 1
                        failed_groups.append(f"{dialog.title}: {str(e)}")
            
            status = f"""
📊 **Forward Status:**
✅ Success: `{success}`
❌ Failed: `{failed}`

🚫 **Failed Groups:**
```
{chr(10).join(failed_groups) if failed_groups else 'None'}
```
            """
            await event.respond(status, parse_mode='md')

        @self.client.on(events.NewMessage(pattern=r'[!/\.]setdelay'))
        async def setdelay_handler(event):
            try:
                delay = int(event.text.split()[1])
                self.delay = delay
                await event.respond(f"⏱️ Delay set to {delay} minutes")
            except:
                await event.respond("❌ Usage: .setdelay <minutes>")

        @self.client.on(events.NewMessage(pattern=r'[!/\.]ban'))
        async def ban_handler(event):
            if event.is_group:
                self.banned_groups.add(event.chat_id)
                await event.respond("🚫 Group banned from receiving forwards")

        @self.client.on(events.NewMessage(pattern=r'[!/\.]listban'))
        async def listban_handler(event):
            banned = []
            for group_id in self.banned_groups:
                group = await self.client.get_entity(group_id)
                banned.append(f"• {group.title}")
            
            await event.respond(f"""
📋 **Banned Groups:**
{chr(10).join(banned) if banned else 'No banned groups'}
            """, parse_mode='md')

        @self.client.on(events.NewMessage(pattern=r'[!/\.]deleteban'))
        async def deleteban_handler(event):
            if event.is_group and event.chat_id in self.banned_groups:
                self.banned_groups.remove(event.chat_id)
                await event.respond("✅ Group removed from ban list")

        @self.client.on(events.NewMessage(pattern=r'[!/\.]stop'))
        async def stop_handler(event):
            self.forwarding = False
            await event.respond("🛑 Forward process stopped")

    async def _check_expiry(self):
        while True:
            check_expiry()
            await asyncio.sleep(3600)  # Check every hour