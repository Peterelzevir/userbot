# config.py
from telethon.sync import TelegramClient
from telethon.errors import SessionPasswordNeededError
from telethon.sessions import StringSession
import json
import os
from datetime import datetime, timedelta

# Configuration
API_ID = "23207350"  # Replace with your API ID
API_HASH = "03464b6c80a5051eead6835928e48189"  # Replace with your API Hash
BOT_TOKEN = "7822772930:AAFQvkd2F9Zn9vzAcBJ5OOuksEwmrFxZBxU"  # Replace with your bot token
ADMIN_IDS = [5988451717]  # Replace with admin user IDs
APP_VERSION = "ᴜꜱᴇʀʙᴏᴛ ʙʏ ʜɪʏᴀᴏᴋ"

# Database file
DB_FILE = "userbot_data.json"

# Helper functions
def load_data():
    if os.path.exists(DB_FILE):
        with open(DB_FILE, 'r') as f:
            return json.load(f)
    return {'userbots': {}, 'banned_groups': {}}

def save_data(data):
    with open(DB_FILE, 'w') as f:
        json.dump(data, f, indent=4)

def check_expiry():
    data = load_data()
    current_time = datetime.now()
    
    for user_id, info in data['userbots'].items():
        if info['active']:
            expiry = datetime.fromisoformat(info['expires_at'])
            if current_time > expiry:
                info['active'] = False
                # Send notification to userbot
                try:
                    client = TelegramClient(StringSession(info['session']), API_ID, API_HASH)
                    with client:
                        client.send_message('me', """
⚠️ **Userbot Expired!**

Your userbot has expired. Please contact @hiyaok to extend your subscription.

Thank you for using our service! 🙏
""", parse_mode='md')
                except:
                    pass
    
    save_data(data)