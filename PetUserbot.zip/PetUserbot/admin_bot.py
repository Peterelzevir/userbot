# admin_bot.py
from telethon import TelegramClient, events, Button
from telethon.tl.functions.users import GetFullUserRequest
from telethon.sessions import StringSession
from telethon.errors import SessionPasswordNeededError
from config import *
import asyncio
from datetime import datetime, timedelta

class AdminBot:
    def __init__(self):
        self.bot = TelegramClient('admin_bot', API_ID, API_HASH)

    async def start(self):
        await self.bot.start(bot_token=BOT_TOKEN)
        
        @self.bot.on(events.NewMessage(pattern='/start'))
        async def start_handler(event):
            user_id = event.sender_id
            if user_id not in ADMIN_IDS:
                await event.respond("👋 Halo, silahkan order bot ke @hiyaok!")
                return

            buttons = [Button.inline("🤖 Buat Userbot", data="create_userbot")]
            await event.respond("👋 Halo admin, silahkan buat userbot disini", buttons=buttons)

        @self.bot.on(events.NewMessage(pattern=r'[!/\.](?:aktif|nonaktif)$'))
        async def toggle_userbot_list_handler(event):
            if event.sender_id not in ADMIN_IDS:
                return
                
            command = event.pattern_match.string.lower()
            should_activate = 'aktif' in command
            action = "Activate" if should_activate else "Deactivate"
                
            data = load_data()
            if not data['userbots']:
                await event.respond("❌ No userbots found!")
                return
                
            buttons = []
            for user_id, info in data['userbots'].items():
                status = "🟢" if info['active'] else "🔴"
                button_text = f"{status} {info['first_name']} ({user_id})"
                buttons.append([Button.inline(
                    button_text, 
                    data=f"{'activate' if should_activate else 'deactivate'}_{user_id}"
                )])

            await event.respond(
                f"🔄 Select userbot to {action.lower()}:",
                buttons=buttons
            )

        @self.bot.on(events.CallbackQuery(pattern=r'^(activate|deactivate)_(\d+)'))
        async def toggle_userbot_callback(event):
            if event.sender_id not in ADMIN_IDS:
                return
                
            action, user_id = event.data.decode().split('_')
            should_activate = action == 'activate'
            
            data = load_data()
            if user_id in data['userbots']:
                data['userbots'][user_id]['active'] = should_activate
                save_data(data)
                
                status = "activated" if should_activate else "deactivated"
                await event.edit(f"""
✅ **Userbot {status}!**

👤 **User Details:**
• ID: `{user_id}`
• Name: `{data['userbots'][user_id]['first_name']}`
• Status: `{'Active' if should_activate else 'Inactive'}`
                """, parse_mode='md')
            else:
                await event.edit("❌ Userbot not found!")

        @self.bot.on(events.NewMessage(pattern=r'[!/\.](?:aktif|nonaktif)\s+(\d+)'))
        async def toggle_userbot_direct_handler(event):
            if event.sender_id not in ADMIN_IDS:
                return
                
            command = event.pattern_match.string.lower()
            should_activate = 'aktif' in command
            
            try:
                user_id = event.pattern_match.group(1)
                data = load_data()
                
                if user_id in data['userbots']:
                    data['userbots'][user_id]['active'] = should_activate
                    save_data(data)
                    
                    status = "activated" if should_activate else "deactivated"
                    await event.respond(f"""
✅ **Userbot {status}!**

👤 **User Details:**
• ID: `{user_id}`
• Name: `{data['userbots'][user_id]['first_name']}`
• Status: `{'Active' if should_activate else 'Inactive'}`
                    """, parse_mode='md')
                else:
                    await event.respond("❌ Userbot not found!")
            except Exception as e:
                await event.respond(f"❌ Error: {str(e)}")

        @self.bot.on(events.CallbackQuery(data="create_userbot"))
        async def create_userbot_handler(event):
            await event.delete()
            async with self.bot.conversation(event.chat_id) as conv:
                # Get API ID
                await conv.send_message("📝 Masukkan API ID:")
                api_id_msg = await conv.get_response()
                api_id = api_id_msg.text

                # Get API Hash
                await conv.send_message("📝 Masukkan API Hash:")
                api_hash_msg = await conv.get_response()
                api_hash = api_hash_msg.text

                # Get phone number
                await conv.send_message("📱 Masukkan nomor telepon:")
                phone_msg = await conv.get_response()
                phone = phone_msg.text

                # Get duration
                await conv.send_message("⏳ Masukkan durasi aktif userbot (dalam hari):")
                duration_msg = await conv.get_response()
                duration = int(duration_msg.text)

                # Create client and get OTP
                client = TelegramClient(StringSession(), api_id, api_hash, device_model=APP_VERSION)
                await client.connect()
                
                await conv.send_message("⏳ Memproses permintaan login...")
                code = await client.send_code_request(phone)
                
                await conv.send_message("📲 Masukkan kode OTP (format: 1 2 3 4 5):")
                otp_msg = await conv.get_response()
                otp = ''.join(otp_msg.text.split())

                try:
                    try:
                        await client.sign_in(phone=phone, code=otp, phone_code_hash=sent_code.phone_code_hash)
                    except SessionPasswordNeededError:
                        await conv.send_message("🔐 Akun ini menggunakan verifikasi 2 langkah. Silahkan masukkan password:")
                        password = await conv.get_response()
                        await client.sign_in(password=password.text)

                    me = await client.get_me()
                    
                    # Save userbot data
                    data = load_data()
                    expiry_date = (datetime.now() + timedelta(days=duration)).isoformat()
                    
                    data['userbots'][str(me.id)] = {
                        'first_name': me.first_name,
                        'last_name': me.last_name,
                        'phone': phone,
                        'created_at': datetime.now().isoformat(),
                        'expires_at': expiry_date,
                        'active': True,
                        'session': client.session.save()
                    }
                    save_data(data)

                    # Format response message
                    response = f"""
🤖 **Userbot berhasil dibuat!**

👤 **Detail Userbot:**
• First Name: `{me.first_name}`
• Last Name: `{me.last_name or 'N/A'}`
• User ID: `{me.id}`
• Phone: `{phone}`
• Created: `{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}`
• Expires: `{datetime.fromisoformat(expiry_date).strftime('%Y-%m-%d %H:%M:%S')}`
                    """
                    await conv.send_message(response, parse_mode='md')
                    
                except Exception as e:
                    await conv.send_message(f"❌ Error: {str(e)}")

        @self.bot.on(events.NewMessage(pattern='/list'))
        async def list_userbots(event):
            if event.sender_id not in ADMIN_IDS:
                return

            data = load_data()
            response = "📋 **List of Userbots:**\n\n"
            
            for user_id, info in data['userbots'].items():
                status = "🟢 Active" if info['active'] else "🔴 Inactive"
                expiry = datetime.fromisoformat(info['expires_at'])
                expires_in = (expiry - datetime.now()).days
                
                response += f"""
👤 **User ID:** `{user_id}`
• Name: `{info['first_name']} {info.get('last_name', '')}`
• Status: {status}
• Phone: `{info['phone']}`
• Expires in: `{expires_in} days`
• Created: `{datetime.fromisoformat(info['created_at']).strftime('%Y-%m-%d')}`
"""
            
            await event.respond(response, parse_mode='md')

        @self.bot.on(events.NewMessage(pattern='/hapus'))
        async def delete_userbot(event):
            if event.sender_id not in ADMIN_IDS:
                return

            try:
                user_id = event.text.split()[1]
                data = load_data()
                
                if user_id in data['userbots']:
                    del data['userbots'][user_id]
                    save_data(data)
                    await event.respond(f"✅ Userbot with ID `{user_id}` has been deleted.", parse_mode='md')
                else:
                    await event.respond("❌ Userbot not found!")
            except Exception as e:
                await event.respond(f"❌ Error: {str(e)}")

        return self.bot