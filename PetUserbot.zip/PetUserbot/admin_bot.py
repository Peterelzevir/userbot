# admin_bot.py
from telethon import TelegramClient, events, Button
from telethon.tl.functions.users import GetFullUserRequest
from telethon.sessions import StringSession
from telethon.errors import SessionPasswordNeededError
from config import *
import asyncio
from datetime import datetime, timedelta
import os
import math
import json

def load_data():
    try:
        with open('data.json', 'r') as f:
            return json.load(f)
    except FileNotFoundError:
        return {'userbots': {}}

def save_data(data):
    with open('data.json', 'w') as f:
        json.dump(data, f, indent=4)

class AdminBot:
    def __init__(self):
        self.bot = TelegramClient('admin_bot', API_ID, API_HASH)
        self.page_size = 10  # Maximum buttons per page
        self.help_pages = {
            'main': {
                'text': """
📚 **Panduan Penggunaan Bot Admin**

Silahkan pilih kategori bantuan di bawah ini:
                """,
                'buttons': [
                    [Button.inline("🤖 Manajemen Userbot", data="help_userbot")],
                    [Button.inline("⚙️ Pengaturan", data="help_settings")],
                    [Button.inline("❌ Tutup", data="help_close")]
                ]
            },
            'userbot': {
                'text': """
🤖 **Panduan Manajemen Userbot**

**Perintah Tersedia:**
• `/start` - Memulai bot dan membuat userbot baru
• `/cek` - Mengecek status semua userbot
• `/hapus` - Menghapus userbot yang ada
• `/help` - Menampilkan bantuan ini

**Catatan:**
• Semua perintah mendukung awalan `/`, `!`, dan `.`
• Klik userbot untuk mengubah status aktif/nonaktif
• Maksimal 10 userbot per halaman
                """,
                'buttons': [
                    [Button.inline("◀️ Kembali", data="help_main")],
                    [Button.inline("❌ Tutup", data="help_close")]
                ]
            },
            'settings': {
                'text': """
⚙️ **Panduan Pengaturan**

**Fitur:**
• Toggle status userbot dengan sekali klik
• Konfirmasi sebelum penghapusan
• Pembersihan otomatis sesi yang tidak terpakai
• Pengecekan sesi ganda

**Tips:**
• Selalu cek status sebelum membuat userbot baru
• Gunakan fitur hapus untuk membersihkan sesi
• Backup data secara berkala
                """,
                'buttons': [
                    [Button.inline("◀️ Kembali", data="help_main")],
                    [Button.inline("❌ Tutup", data="help_close")]
                ]
            }
        }

    async def start(self):
        await self.bot.start(bot_token=BOT_TOKEN)
        
        @self.bot.on(events.NewMessage(pattern=r'(?i)[!/\.]help$'))
        async def help_handler(event):
            if event.sender_id not in ADMIN_IDS:
                await event.reply("👋 **Halo**, silahkan order bot ke @hiyaok!")
                return

            help_page = self.help_pages['main']
            await event.reply(help_page['text'], buttons=help_page['buttons'])

        @self.bot.on(events.CallbackQuery(pattern=r'^help_(\w+)'))
        async def help_callback(event):
            if event.sender_id not in ADMIN_IDS:
                return

            page = event.data.decode().split('_')[1]
            if page == 'close':
                await event.delete()
                return

            help_page = self.help_pages.get(page, self.help_pages['main'])
            await event.edit(help_page['text'], buttons=help_page['buttons'])

        @self.bot.on(events.NewMessage(pattern=r'(?i)[!/\.]start$'))
        async def start_handler(event):
            user_id = event.sender_id
            if user_id not in ADMIN_IDS:
                await event.reply("👋 **Halo**, silahkan order bot ke @hiyaok!")
                return

            buttons = [
                [Button.inline("🤖 Buat Userbot", data="create_userbot")],
                [Button.inline("❓ Bantuan", data="help_main")]
            ]
            await event.reply("👋 **Halo admin**, silahkan buat userbot disini", buttons=buttons)

        @self.bot.on(events.CallbackQuery(data="create_userbot"))
        async def create_userbot_handler(event):
            await event.delete()
            async with self.bot.conversation(event.chat_id) as conv:
                # Get API ID
                await conv.send_message("📝 **Masukkan API ID:**")
                api_id_msg = await conv.get_response()
                api_id = api_id_msg.text

                # Get API Hash
                await conv.send_message("📝 **Masukkan API Hash:**")
                api_hash_msg = await conv.get_response()
                api_hash = api_hash_msg.text

                # Get phone number
                await conv.send_message("📱 **Masukkan nomor telepon:**")
                phone_msg = await conv.get_response()
                phone = phone_msg.text

                # Check existing session
                data = load_data()
                existing_userbot = None
                for user_id, info in data['userbots'].items():
                    if info['phone'] == phone:
                        existing_userbot = info
                        break

                if existing_userbot:
                    status = "🟢 Aktif" if existing_userbot['active'] else "🔴 Nonaktif"
                    text = f"""
⚠️ **Sesi Ditemukan!**

👤 **Detail Userbot:**
• Nama: `{existing_userbot['first_name']}`
• Status: {status}
• Phone: `{phone}`

❓ **Apakah Anda ingin menghapus sesi ini dan membuat yang baru?**
                    """
                    buttons = [
                        [
                            Button.inline("✅ Ya, Hapus & Buat Baru", data=f"delete_create_{phone}"),
                            Button.inline("❌ Tidak, Batalkan", data="cancel_create")
                        ]
                    ]
                    await conv.send_message(text, buttons=buttons)
                    return

                # Get duration
                await conv.send_message("⏳ **Masukkan durasi aktif userbot (dalam hari):**")
                duration_msg = await conv.get_response()
                duration = int(duration_msg.text)

                await self.create_new_userbot(conv, phone, api_id, api_hash, duration)

        @self.bot.on(events.CallbackQuery(pattern=r'^delete_create_(\d+)'))
        async def delete_and_create_callback(event):
            if event.sender_id not in ADMIN_IDS:
                return

            phone = event.data.decode().split('_')[2]
            data = load_data()
            
            # Delete existing userbot with this phone
            user_id_to_delete = None
            for user_id, info in data['userbots'].items():
                if info['phone'] == phone:
                    user_id_to_delete = user_id
                    break

            if user_id_to_delete:
                try:
                    session = StringSession(data['userbots'][user_id_to_delete]['session'])
                    if os.path.exists(f"{session}.session"):
                        os.remove(f"{session}.session")
                except:
                    pass
                
                del data['userbots'][user_id_to_delete]
                save_data(data)

            # Start new userbot creation
            async with self.bot.conversation(event.chat_id) as conv:
                await event.delete()
                await conv.send_message("✅ **Sesi lama telah dihapus. Memulai pembuatan userbot baru...**")
                
                # Get API ID
                await conv.send_message("📝 **Masukkan API ID:**")
                api_id_msg = await conv.get_response()
                api_id = api_id_msg.text

                # Get API Hash
                await conv.send_message("📝 **Masukkan API Hash:**")
                api_hash_msg = await conv.get_response()
                api_hash = api_hash_msg.text

                # Get duration
                await conv.send_message("⏳ **Masukkan durasi aktif userbot (dalam hari):**")
                duration_msg = await conv.get_response()
                duration = int(duration_msg.text)

                await self.create_new_userbot(conv, phone, api_id, api_hash, duration)

        async def create_new_userbot(self, conv, phone, api_id, api_hash, duration):
            # Create client and get OTP
            client = TelegramClient(StringSession(), api_id, api_hash, device_model=APP_VERSION)
            await client.connect()
            
            await conv.send_message("⏳ **Memproses permintaan login...**")
            code = await client.send_code_request(phone)
            
            await conv.send_message("📲 **Masukkan kode OTP (format: 1 2 3 4 5):**")
            otp_msg = await conv.get_response()
            otp = ''.join(otp_msg.text.split())

            try:
                try:
                    await client.sign_in(phone=phone, code=otp, phone_code_hash=code.phone_code_hash)
                except SessionPasswordNeededError:
                    await conv.send_message("🔐 **Akun ini menggunakan verifikasi 2 langkah. Silahkan masukkan password:**")
                    password = await conv.get_response()
                    await client.sign_in(password=password.text)

                me = await client.get_me()
                
                # Save userbot data
                data = load_data()
                expiry_date = (datetime.now() + timedelta(days=duration)).isoformat()
                
                data['userbots'][str(me.id)] = {
                    'first_name': me.first_name,
                    'last_name': me.last_name,
                    'phone': phone,
                    'created_at': datetime.now().isoformat(),
                    'expires_at': expiry_date,
                    'active': True,
                    'session': client.session.save()
                }
                save_data(data)

                # Format response message
                response = f"""
🤖 **Userbot berhasil dibuat!**

👤 **Detail Userbot:**
• First Name: `{me.first_name}`
• Last Name: `{me.last_name or 'N/A'}`
• User ID: `{me.id}`
• Phone: `{phone}`
• Created: `{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}`
• Expires: `{datetime.fromisoformat(expiry_date).strftime('%Y-%m-%d %H:%M:%S')}`
                """
                await conv.send_message(response, parse_mode='md')
                
            except Exception as e:
                await conv.send_message(f"❌ **Error:** `{str(e)}`")

        @self.bot.on(events.CallbackQuery(pattern='cancel_create'))
        async def cancel_create_callback(event):
            if event.sender_id not in ADMIN_IDS:
                return
                
            await event.edit("❌ **Pembuatan userbot dibatalkan!**")

        @self.bot.on(events.NewMessage(pattern=r'(?i)[!/\.]cek'))
        async def check_userbot_handler(event):
            if event.sender_id not in ADMIN_IDS:
                return
                
            await self.show_userbot_list(event, page=0)

        async def show_userbot_list(self, event, page=0):
            data = load_data()
            if not data['userbots']:
                await event.reply("❌ **Tidak ada userbot yang ditemukan!**")
                return

            userbots = list(data['userbots'].items())
            total_pages = math.ceil(len(userbots) / self.page_size)
            start_idx = page * self.page_size
            end_idx = start_idx + self.page_size
            current_page_userbots = userbots[start_idx:end_idx]

            buttons = []
            for user_id, info in current_page_userbots:
                status = "🟢" if info['active'] else "🔴"
                button_text = f"{status} {info['first_name']} ({user_id})"
                buttons.append([Button.inline(button_text, data=f"toggle_{user_id}")])

            # Add navigation buttons if needed
            nav_buttons = []
            if page > 0:
                nav_buttons.append(Button.inline("⬅️ Kembali", data=f"page_{page-1}"))
            if page < total_pages - 1:
                nav_buttons.append(Button.inline("Lanjut ➡️", data=f"page_{page+1}"))
            if nav_buttons:
                buttons.append(nav_buttons)

            buttons.append([Button.inline("❓ Bantuan", data="help_main")])

            active_count = sum(1 for _, info in data['userbots'].items() if info['active'])
            inactive_count = len(data['userbots']) - active_count
            
            text = f"""
📊 **Statistik Userbot:**
• Total: `{len(data['userbots'])}`
• Aktif: `{active_count}`
• Nonaktif: `{inactive_count}`

🔄 **Silahkan pilih userbot untuk mengubah status:**
            """
            
            if event.message:
                await event.reply(text, buttons=buttons)
            else:
                await event.edit(text, buttons=buttons)

        @self.bot.on(events.CallbackQuery(pattern=r'^page_(\d+)'))
        async def page_callback(event):
            if event.sender_id not in ADMIN_IDS:
                return
                
            page = int(event.data.decode().split('_')[1])
            await self.show_userbot_list(event, page)

        @self.bot.on(events.CallbackQuery(pattern=r'^toggle_(\d+)'))
        async def toggle_userbot_callback(event):
            if event.sender_id not in ADMIN_IDS:
                return
                
            user_id = event.data.decode().split('_')[1]
            data = load_data()
            
            if user_id in data['userbots']:
                # Toggle status
                data['userbots'][user_id]['active'] = not data['userbots'][user_id]['active']
                save_data(data)
                
                # Update the message with new status
                page = 0  # You might want to track the current page
                await self.show_userbot_list(event, page)

        @self.bot.on(events.NewMessage(pattern=r'(?i)[!/\.]hapus'))
        async def delete_userbot_handler(event):
            if event.sender_id not in ADMIN_IDS:
                return

            data = load_data()
            if not data['userbots']:
                await event.reply("❌ **Tidak ada userbot yang ditemukan!**")
                return

            active_count = sum(1 for _, info in data['userbots'].items() if info['active'])
            inactive_count = len(data['userbots']) - active_count

            text = f"""
📊 **Statistik Userbot:**
• Total: `{len(data['userbots'])}`
• Aktif: `{active_count}`
• Nonaktif: `{inactive_count}`

❌ **Silahkan pilih userbot yang ingin dihapus:**
            """

            buttons = []
            page = 0
            userbots = list(data['userbots'].items())
            total_pages = math.ceil(len(userbots) / self.page_size)
            start_idx = page * self.page_size
            end_idx = start_idx + self.page_size
            current_page_userbots = userbots[start_idx:end_idx]

            for user_id, info in current_page_userbots:
                status = "🟢" if info['active'] else "🔴"
                button_text = f"{status} {info['first_name']} ({user_id})"
                buttons.append([Button.inline(button_text, data=f"delete_{user_id}")])

            # Add navigation buttons if needed
            nav_buttons = []
            if total_pages > 1:
                nav_buttons.append(Button.inline("Lanjut ➡️", data="delete_page_1"))
            if nav_buttons:
                buttons.append(nav_buttons)

            await event.reply(text, buttons=buttons)

        @self.bot.on(events.CallbackQuery(pattern=r'^delete_page_(\d+)'))
        async def delete_page_callback(event):
            if event.sender_id not in ADMIN_IDS:
                return
                
            page = int(event.data.decode().split('_')[2])
            data = load_data()
            
            buttons = []
            userbots = list(data['userbots'].items())
            total_pages = math.ceil(len(userbots) / self.page_size)
            start_idx = page * self.page_size
            end_idx = start_idx + self.page_size
            current_page_userbots = userbots[start_idx:end_idx]

            for user_id, info in current_page_userbots:
                status = "🟢" if info['active'] else "🔴"
                button_text = f"{status} {info['first_name']} ({user_id})"
                buttons.append([Button.inline(button_text, data=f"delete_{user_id}")])

            # Add navigation buttons
            nav_buttons = []
            if page > 0:
                nav_buttons.append(Button.inline("⬅️ Kembali", data=f"delete_page_{page-1}"))
            if page < total_pages - 1:
                nav_buttons.append(Button.inline("Lanjut ➡️", data=f"delete_page_{page+1}"))
            if nav_buttons:
                buttons.append(nav_buttons)

            active_count = sum(1 for _, info in data['userbots'].items() if info['active'])
            inactive_count = len(data['userbots']) - active_count

            text = f"""
📊 **Statistik Userbot:**
• Total: `{len(data['userbots'])}`
• Aktif: `{active_count}`
• Nonaktif: `{inactive_count}`

❌ **Silahkan pilih userbot yang ingin dihapus:**
            """

            await event.edit(text, buttons=buttons)

        @self.bot.on(events.CallbackQuery(pattern=r'^delete_(\d+)'))
        async def delete_confirmation_callback(event):
            if event.sender_id not in ADMIN_IDS:
                return
                
            user_id = event.data.decode().split('_')[1]
            data = load_data()
            
            if user_id in data['userbots']:
                info = data['userbots'][user_id]
                text = f"""
⚠️ **Konfirmasi Penghapusan Userbot**

👤 **Detail Userbot:**
• Nama: `{info['first_name']}`
• ID: `{user_id}`
• Status: `{'Aktif' if info['active'] else 'Nonaktif'}`
• Phone: `{info['phone']}`

❓ **Apakah Anda yakin ingin menghapus userbot ini?**
                """
                
                buttons = [
                    [
                        Button.inline("✅ Konfirmasi", data=f"confirm_delete_{user_id}"),
                        Button.inline("❌ Batalkan", data="cancel_delete")
                    ]
                ]
                
                await event.edit(text, buttons=buttons)

        @self.bot.on(events.CallbackQuery(pattern=r'^confirm_delete_(\d+)'))
        async def confirm_delete_callback(event):
            if event.sender_id not in ADMIN_IDS:
                return
                
            user_id = event.data.decode().split('_')[2]
            data = load_data()
            
            if user_id in data['userbots']:
                # Delete the session file if it exists
                session_string = data['userbots'][user_id]['session']
                try:
                    # Clean up any session files
                    session = StringSession(session_string)
                    if os.path.exists(f"{session}.session"):
                        os.remove(f"{session}.session")
                except:
                    pass
                
                # Remove from data
                del data['userbots'][user_id]
                save_data(data)
                
                await event.edit("✅ **Userbot berhasil dihapus!**")
            else:
                await event.edit("❌ **Userbot tidak ditemukan!**")

        @self.bot.on(events.CallbackQuery(pattern='cancel_delete'))
        async def cancel_delete_callback(event):
            if event.sender_id not in ADMIN_IDS:
                return
                
            await event.edit("❌ **Penghapusan userbot dibatalkan!**")

        return self.bot